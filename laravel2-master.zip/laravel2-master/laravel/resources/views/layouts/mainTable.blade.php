<!DOCTYPE html>
<html lang="en">
<head>

@include('partialsMainTable.head')

</head>

<body class="body-wrapper">


@include('partialsMainTable.topbar')

@yield('content')

@include('partialsMainTable.footer')

</body>
</html>



