<!DOCTYPE html>
<html>
<head>
<title>
contact us
</title>
<style type="text/css">
#about
{
	float: left;
}
</style>
<link rel="stylesheet"  href="contact.css">
</head>
@section ('body')
<body>
<div id="about">
<h1>
	about page</h1>
	<a href="/homepage"><input id="home" type="submit" value="back to home page "></a>
</div>
</body>