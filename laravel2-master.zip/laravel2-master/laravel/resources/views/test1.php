<html>
<body

<h1>
<?php echo "hello".$name;?></h1>
</body>
</html>