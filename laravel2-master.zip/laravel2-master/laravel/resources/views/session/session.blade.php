<h1>
welcome
@if(session('message'))
<p>{{session('message')}}</p>
@endif
</h1>