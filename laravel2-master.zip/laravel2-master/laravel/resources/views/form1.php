<!DOCTYPE html>
<html>
<body>

<h2>HTML Forms</h2>

 <fieldset>
  <legend>Form:</legend>

<form action="/laravel/public/user/register" method="post">
  <input type ="hidden" name="_token" value="<?php echo csrf_token()?>">
  First name:<br>
  <input type="text" name="firstname" value="Mickey">
  <br>
  Last name:<br>
  <input type="text" name="lastname" value="Mouse">
  <br><br>
  password:<br>
  <input type="password"  value="">
  <br>
  <br>
  <input>
  <select><option>date</option></select>
  <br>
  <input type="submit" value="Submit">
</form> 
</fieldset>
<p>If you click the "Submit" button, </p>

</body>
</html>
