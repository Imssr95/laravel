<!DOCTYPE html>
<html>
<body>
<form action="re/abc" method="POST">
	{{method_field('DELETE')}}
	{{csrf_field()}}
<input type="submit" value="submit">
</form>
</body>
</html>