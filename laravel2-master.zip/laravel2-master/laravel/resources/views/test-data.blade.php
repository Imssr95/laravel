<h1>hello</h1>
<?php print_r($data); 
print_r($addresses); 
?>