<html>
<h1 style ="color:blue; weight:bolder;"> BAR</h1>

<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
<nav class="navbar navbar-default " role="navigation">
  <div class="container-fluid">
    <div class="navbar-header">
	  	<div class="-menu">
        <ul>
          <br>
            <li><a href="#" class="active">HOME</a></li>
            <br>
            <li><a href="#">ABOUT US</a></li>
            <br>
            <li><a href="#">LOGIN</a></li>
            <br>
            <li><a href="contact1">CONTACT US</a></li>
            <form>

            <br>
            <div class="dropdown">
   <div class="dropdown-content">
   
    <p style ="color:blue; weight:bolder;">PHONE NUMBER</p>
    <P>EMAIL id </P>
    <p>and information</p>
  </div>
</div>
        </ul>
    </div>
    </div>
  </div>
</nav>
</html>



