<html>
<head>
<title>
app name -@yield('title')</title>
</title>
<body>
<br>
@section()('sidebar')
this is the master sidebar
<div class="cntainer">

@yield('content') </div>

</body>
