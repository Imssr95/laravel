<?php
return [

    'previous' => '«Anterior',
    'next' => 'Adelante»',

];