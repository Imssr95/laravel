<?php
return [

    'reset' => 'Su contraseña ha sido reseteada!',
    'password' => 'Las contraseñas deben tener al menos seis caracteres y coincidir con la confirmación.',
    'sent' => 'Hemos enviado por correo electrónico su enlace de restablecimiento de contraseña!',
    'token' => 'This password reset token is invalid.',
    'user' => 'No podemos encontrar un usuario con esa dirección de correo electrónico.',

];