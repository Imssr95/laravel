<?php
return [

    'failed' => 'Bilgiler kayıtlarımızla uyuşmuyor',
    'throttle' => 'Giriş yapmayı çok denediniz. Lütfen :seconds sonra tekrar deneyin',

];