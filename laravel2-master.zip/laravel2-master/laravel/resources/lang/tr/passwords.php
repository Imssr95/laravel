<?php
return [

    'password' => 'Şifre en az 6 karakterli olmalı ve onay alanıyla aynı olmalı',
    'reset' => 'Şifreniz yenilendi!',
    'sent' => 'E-posta adresinize şifre yenileme postası gönderildi!',
    'token' => 'Şifre yenileme işareti geçersiz.',
    'user' => 'Bu e-posta adresiyle bir hesap bulamadık.',

];