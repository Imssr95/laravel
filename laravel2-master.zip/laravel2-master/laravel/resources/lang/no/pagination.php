<?php
return [

    'previous' => '« forrige',
    'next' => 'Neste »',

];