<?php
return [

    'previous' => 'Предыдущая',
    'next' => 'Следующая',

];