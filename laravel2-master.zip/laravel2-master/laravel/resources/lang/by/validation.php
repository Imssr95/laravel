<?php
return [

    'accepted' => 'Значэнне :attribute павінна быць прынята.',
    'active_url' => 'Значэнне :attribute не ёсць спасылкай.',

];