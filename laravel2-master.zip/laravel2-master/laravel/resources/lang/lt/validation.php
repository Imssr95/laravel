<?php
return [

    'active_url' => ':attribute netinkamas URL.',
    'after' => 'Laukas :attribute turi būti data po :date.',
    'alpha' => 'Laukas :attribute gali būti sudarytas tik iš raidžių.',
    'alpha_dash' => 'Laukas :attribute gali būti sudarytas tik iš raidžių, skaičių ir brūkšnių.',
    'alpha_num' => 'Laukas :attribute gali būti sudarytas tik iš raidžių ir skaičių.',
    'array' => 'Laukas :attribute turi būti masyvas.',
    'before' => 'Laukas :attribute turi būti data prieš :date.',
    'between' => [
        'numeric' => 'Lauko :attribute reikšmė turi būti tarp :min ir :max.',
    ],

];