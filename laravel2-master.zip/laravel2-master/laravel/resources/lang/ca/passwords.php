<?php
return [

    'password' => 'La contrassenya ha de tenir almenys 6 caràcters i ha de ser confirmada',
    'reset' => 'La teva contrassenya s\'ha restablert!',
    'sent' => 'Hem enviat per correu el teu link per restablir la contrassenya!',
    'token' => 'Aquest token per restablir la contrasenya és invàlid',
    'user' => 'No trobem un usuari amb aquesta adreça de correu',

];