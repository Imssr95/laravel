<?php
return [

    'previous' => '« Anterior',
    'next' => 'Següent »',

];