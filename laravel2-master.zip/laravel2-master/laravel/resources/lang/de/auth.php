<?php
return [

    'failed' => 'Diese Kontodaten sind uns nicht bekannt.',
    'throttle' => 'Zu viele fehlerhafte Versuche. Bitte versuchen sie es in :seconds Sekunden erneut.',

];