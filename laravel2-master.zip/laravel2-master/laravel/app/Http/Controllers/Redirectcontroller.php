<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Redirectcontroller extends Controller
{
    public function index()
    {
    	echo "Redirect to controller s action";
    }
}
